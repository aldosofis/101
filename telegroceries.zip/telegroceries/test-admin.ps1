# Test script for Telegroceries admin functionality
Write-Host "Testing Telegroceries Admin Functionality" -ForegroundColor Green

# Test 1: Check if server is running
Write-Host "1. Testing server availability..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:3000" -Method GET -UseBasicParsing
    if ($response.StatusCode -eq 200) {
        Write-Host "   ✓ Server is running successfully" -ForegroundColor Green
    }
} catch {
    Write-Host "   ✗ Server is not accessible" -ForegroundColor Red
    exit 1
}

# Test 2: Test admin login page access
Write-Host "2. Testing admin login page..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:3000/admin/login" -Method GET -UseBasicParsing
    if ($response.StatusCode -eq 200) {
        Write-Host "   ✓ Admin login page is accessible" -ForegroundColor Green
    }
} catch {
    Write-Host "   ✗ Admin login page is not accessible" -ForegroundColor Red
}

# Test 3: Test admin authentication (should redirect without credentials)
Write-Host "3. Testing admin authentication..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:3000/admin" -Method GET -UseBasicParsing
    if ($response.StatusCode -eq 200 -and $response.Content -like "*Admin Login*") {
        Write-Host "   ✓ Admin authentication is working (redirected to login)" -ForegroundColor Green
    }
} catch {
    Write-Host "   ✓ Admin authentication is working (access denied)" -ForegroundColor Green
}

Write-Host ""
Write-Host "Admin Login Credentials:" -ForegroundColor Cyan
Write-Host "Username: admin" -ForegroundColor White
Write-Host "Password: password" -ForegroundColor White
Write-Host ""
Write-Host "You can now access the admin panel at: http://localhost:3000/admin/login" -ForegroundColor Green
Write-Host "The main store is available at: http://localhost:3000" -ForegroundColor Green