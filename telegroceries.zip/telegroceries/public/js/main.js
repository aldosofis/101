// DOM Elements
const cartIcon = document.getElementById('cart-icon');
const cartSidebar = document.getElementById('cart-sidebar');
const cartOverlay = document.getElementById('cart-overlay');
const closeCart = document.getElementById('close-cart');
const cartItems = document.getElementById('cart-items');
const cartCount = document.getElementById('cart-count');
const cartTotal = document.getElementById('cart-total');
const checkoutBtn = document.getElementById('checkout-btn');
const checkoutModal = document.getElementById('checkout-modal');
const closeCheckout = document.getElementById('close-checkout');
const checkoutForm = document.getElementById('checkout-form');

// Initialize cart
let cart = [];

// Load cart from server on page load
async function loadCartFromServer() {
    try {
        const response = await fetch('/api/cart');
        if (response.ok) {
            const data = await response.json();
            cart = data.cart || [];
            updateCartUI();
        }
    } catch (error) {
        console.error('Error loading cart:', error);
    }
}

// Mobile performance improvements
function optimizeForMobile() {
    // Disable hover effects on touch devices
    if ('ontouchstart' in window) {
        document.documentElement.classList.add('touch-device');
    }
    
    // Prevent scrolling when modals are open
    const preventScroll = (e) => {
        if (document.body.classList.contains('overflow-hidden')) {
            e.preventDefault();
        }
    };
    
    document.addEventListener('touchmove', preventScroll, { passive: false });
    
    // Optimize scroll performance
    let ticking = false;
    const updateScrollPosition = () => {
        // Update any scroll-dependent elements here
        ticking = false;
    };
    
    document.addEventListener('scroll', () => {
        if (!ticking) {
            requestAnimationFrame(updateScrollPosition);
            ticking = true;
        }
    }, { passive: true });
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    // Initialize mobile optimizations
    optimizeForMobile();
    
    // Initialize cart
    loadCartFromServer();
    
    // Mobile menu functionality
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');
    const menuLine1 = document.getElementById('menu-line-1');
    const menuLine2 = document.getElementById('menu-line-2');
    const menuLine3 = document.getElementById('menu-line-3');
    
    if (mobileMenuBtn && mobileMenu) {
        mobileMenuBtn.addEventListener('click', () => {
            toggleMobileMenu();
        });
    }
    
    // Initialize tooltips
    const tooltipTriggers = document.querySelectorAll('[data-tooltip]');
    tooltipTriggers.forEach(trigger => {
        trigger.addEventListener('mouseenter', showTooltip);
        trigger.addEventListener('mouseleave', hideTooltip);
    });

    // Cart toggle
    if (cartIcon) cartIcon.addEventListener('click', toggleCart);
    if (closeCart) closeCart.addEventListener('click', closeCartSidebar);
    if (cartOverlay) cartOverlay.addEventListener('click', closeCartSidebar);
    
    // Checkout modal
    if (checkoutBtn) checkoutBtn.addEventListener('click', openCheckoutModal);
    if (closeCheckout) closeCheckout.addEventListener('click', closeCheckoutModal);
    
    // Back to cart button
    const backToCart = document.getElementById('back-to-cart');
    if (backToCart) backToCart.addEventListener('click', closeCheckoutModal);
    
    // Close modal when clicking outside
    const checkoutModal = document.getElementById('checkout-modal');
    if (checkoutModal) {
        checkoutModal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeCheckoutModal();
            }
        });
    }
    
    // Form submission
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', handleCheckout);
    }

    // Category filtering
    const categoryFilters = document.querySelectorAll('.category-filter');
    categoryFilters.forEach(filter => {
        filter.addEventListener('click', filterProducts);
    });

    // Tabs for product page
    const tabBtns = document.querySelectorAll('#product-tabs .tab-btn');
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const tabId = btn.getAttribute('data-tab');
            
            // Update active tab button
            tabBtns.forEach(b => {
                b.classList.remove('active', 'text-blue-600', 'border-blue-600', 'bg-blue-50');
                b.classList.add('text-gray-500');
            });
            btn.classList.remove('text-gray-500');
            btn.classList.add('active', 'text-blue-600', 'border-blue-600', 'bg-blue-50');
            
            // Show corresponding tab content
            const tabContents = document.querySelectorAll('.tab-content');
            tabContents.forEach(content => {
                content.classList.add('hidden');
                content.classList.remove('active');
            });
            
            const activeTab = document.getElementById(tabId + '-tab');
            if (activeTab) {
                activeTab.classList.remove('hidden');
                activeTab.classList.add('active');
            }
        });
    });

    // Package Selection
    const packageOptions = document.querySelectorAll('.package-option');
    let selectedPackage = null;
    
    packageOptions.forEach(option => {
        option.addEventListener('click', () => {
            // Remove selection from all options
            packageOptions.forEach(opt => {
                opt.classList.remove('selected', 'border-blue-500', 'bg-blue-50');
                opt.classList.add('border-gray-200');
                const radio = opt.querySelector('.package-radio');
                const dot = opt.querySelector('.package-dot');
                if (radio) radio.classList.remove('border-blue-500');
                if (dot) dot.classList.remove('scale-100');
            });
            
            // Add selection to clicked option
            option.classList.add('selected', 'border-blue-500', 'bg-blue-50');
            option.classList.remove('border-gray-200');
            const radio = option.querySelector('.package-radio');
            const dot = option.querySelector('.package-dot');
            if (radio) radio.classList.add('border-blue-500');
            if (dot) dot.classList.add('scale-100');
            
            // Update selected package
            selectedPackage = {
                id: option.dataset.packageId,
                name: option.dataset.name,
                price: parseFloat(option.dataset.price)
            };
            
            // Update total price
            updateProductPrice();
        });
    });
    
    // Initialize first package as selected
    if (packageOptions.length > 0) {
        packageOptions[0].click();
    }
    
    // Quantity controls for product page
    const productQuantity = document.getElementById('product-quantity');
    const quantityBtns = document.querySelectorAll('.quantity-btn');
    
    quantityBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const isPlus = btn.classList.contains('plus');
            const isMinus = btn.classList.contains('minus');
            
            if (isPlus || isMinus) {
                let currentQuantity = parseInt(productQuantity.value) || 1;
                
                if (isPlus) {
                    currentQuantity++;
                } else if (isMinus && currentQuantity > 1) {
                    currentQuantity--;
                }
                
                productQuantity.value = currentQuantity;
                updateProductPrice();
            }
        });
    });
    
    if (productQuantity) {
        productQuantity.addEventListener('input', updateProductPrice);
    }

    // Keyboard support
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const checkoutModal = document.getElementById('checkout-modal');
            const loadingOverlay = document.getElementById('loading-overlay');
            
            if (checkoutModal && !checkoutModal.classList.contains('invisible')) {
                closeCheckoutModal();
            } else if (loadingOverlay && !loadingOverlay.classList.contains('invisible')) {
                hideLoadingOverlay();
            } else if (isMobileMenuOpen) {
                closeMobileMenu();
            } else if (!cartSidebar.classList.contains('translate-x-full')) {
                closeCartSidebar();
            }
        }
    });

    // Close mobile menu when clicking links
    document.querySelectorAll('#mobile-menu a').forEach(link => {
        link.addEventListener('click', () => {
            closeMobileMenu();
        });
    });

    // Add to cart buttons
    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('add-to-cart')) {
            e.preventDefault();
            const productId = parseInt(e.target.dataset.id);
            const product = products.find(p => p.id === productId);
            
            if (product) {
                addToCart(product);
            }
        }
    });
});

// Product Page Functions
function updateProductPrice() {
    const quantityInput = document.getElementById('product-quantity');
    const totalPriceElement = document.getElementById('total-price');
    
    if (!quantityInput || !totalPriceElement) return;
    
    const quantity = parseInt(quantityInput.value) || 1;
    let unitPrice = 0;
    
    if (selectedPackage) {
        unitPrice = selectedPackage.price;
    } else {
        // Fallback to original product price if no package is selected
        const addToCartBtn = document.querySelector('.add-to-cart');
        if (addToCartBtn) {
            unitPrice = parseFloat(addToCartBtn.dataset.price) || 0;
        }
    }
    
    const totalPrice = unitPrice * quantity;
    totalPriceElement.textContent = '$' + totalPrice.toFixed(2);
}

function viewProduct(productId) {
    window.location.href = '/product/' + productId;
}

// Cart Functions
async function addToCart(product, quantity = 1) {
    const existingItem = cart.find(item => item.id === product.id);
    
    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            image: product.image,
            quantity: quantity
        });
    }
    
    await updateCart();
    showNotification(`${product.name} added to cart`, 'success');
}

async function updateCart() {
    try {
        const response = await fetch('/api/cart/update', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ cart })
        });
        
        if (response.ok) {
            updateCartUI();
        }
    } catch (error) {
        console.error('Error updating cart:', error);
    }
}

function updateCartUI() {
    if (!cartItems) return;
    
    if (cart.length === 0) {
        cartItems.innerHTML = '<p class="text-gray-500 text-center py-8">Your cart is empty</p>';
        cartCount.textContent = '0';
        cartTotal.textContent = '$0.00';
        if (checkoutBtn) checkoutBtn.disabled = true;
        return;
    }
    
    // Render cart items
    cartItems.innerHTML = cart.map(item => `
        <div class="cart-item flex items-center py-4 border-b border-gray-200" data-id="${item.id}">
            <img src="${item.image}" alt="${item.name}" class="w-16 h-16 object-cover rounded">
            <div class="ml-4 flex-1">
                <h3 class="font-medium text-gray-900">${item.name}</h3>
                <p class="text-gray-600">$${item.price.toFixed(2)} x ${item.quantity}</p>
            </div>
            <div class="flex items-center">
                <button class="quantity-btn minus px-2 py-1 bg-gray-100 rounded-l" data-id="${item.id}">-</button>
                <input type="number" min="1" value="${item.quantity}" class="w-12 text-center border-t border-b border-gray-300">
                <button class="quantity-btn plus px-2 py-1 bg-gray-100 rounded-r" data-id="${item.id}">+</button>
                <button class="remove-item ml-2 text-red-500" data-id="${item.id}">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                </button>
            </div>
        </div>
    `).join('');
    
    // Update cart count and total
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    const totalPrice = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    cartCount.textContent = totalItems;
    cartTotal.textContent = `$${totalPrice.toFixed(2)}`;
    if (checkoutBtn) checkoutBtn.disabled = false;
}

async function updateCartItemQuantity(productId, newQuantity) {
    const item = cart.find(item => item.id === productId);
    if (item) {
        item.quantity = Math.max(1, newQuantity);
        await updateCart();
    }
}

async function removeFromCart(productId) {
    try {
        const response = await fetch('/api/cart/remove', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ productId: productId })
        });
        
        if (response.ok) {
            const data = await response.json();
            if (data.success) {
                cart = data.cart;
                updateCartUI();
                return true;
            }
        }
        
        throw new Error('Failed to remove item from cart');
    } catch (error) {
        console.error('Error removing from cart:', error);
        // Fallback to local removal
        cart = cart.filter(item => item.id !== productId);
        await updateCart();
        return false;
    }
}

// Mobile Menu Functions
let isMobileMenuOpen = false;

function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobile-menu');
    const menuLine1 = document.getElementById('menu-line-1');
    const menuLine2 = document.getElementById('menu-line-2');
    const menuLine3 = document.getElementById('menu-line-3');
    
    if (!mobileMenu) return;
    
    isMobileMenuOpen = !isMobileMenuOpen;
    
    if (isMobileMenuOpen) {
        // Open menu
        mobileMenu.classList.remove('-translate-y-full', 'opacity-0');
        mobileMenu.classList.add('translate-y-0', 'opacity-100');
        document.body.classList.add('overflow-hidden');
        
        // Animate hamburger to X
        if (menuLine1 && menuLine2 && menuLine3) {
            menuLine1.classList.add('rotate-45', 'translate-y-2');
            menuLine2.classList.add('opacity-0');
            menuLine3.classList.add('-rotate-45', '-translate-y-2');
        }
    } else {
        // Close menu
        mobileMenu.classList.add('-translate-y-full', 'opacity-0');
        mobileMenu.classList.remove('translate-y-0', 'opacity-100');
        document.body.classList.remove('overflow-hidden');
        
        // Animate X back to hamburger
        if (menuLine1 && menuLine2 && menuLine3) {
            menuLine1.classList.remove('rotate-45', 'translate-y-2');
            menuLine2.classList.remove('opacity-0');
            menuLine3.classList.remove('-rotate-45', '-translate-y-2');
        }
    }
}

function closeMobileMenu() {
    if (isMobileMenuOpen) {
        toggleMobileMenu();
    }
}

// Cart UI Functions
function toggleCart() {
    const isOpen = !cartSidebar.classList.contains('translate-x-full');
    
    if (isOpen) {
        closeCartSidebar();
    } else {
        openCartSidebar();
    }
}

function openCartSidebar() {
    cartSidebar.classList.remove('translate-x-full');
    if (cartOverlay) {
        cartOverlay.classList.remove('opacity-0', 'invisible');
    }
    document.body.classList.add('overflow-hidden');
    
    // Close mobile menu if open
    closeMobileMenu();
}

function closeCartSidebar() {
    cartSidebar.classList.add('translate-x-full');
    if (cartOverlay) {
        cartOverlay.classList.add('opacity-0', 'invisible');
    }
    document.body.classList.remove('overflow-hidden');
}

// Checkout Functions
function openCheckoutModal() {
    if (cart.length === 0) {
        showNotification('Your cart is empty', 'error');
        return;
    }
    
    const modal = document.getElementById('checkout-modal');
    const content = document.getElementById('checkout-content');
    
    // Update order summary in modal
    updateCheckoutSummary();
    
    modal.classList.remove('opacity-0', 'invisible');
    document.body.classList.add('overflow-hidden');
    
    setTimeout(() => {
        content.classList.remove('scale-95');
        content.classList.add('scale-100');
    }, 10);
}

function closeCheckoutModal() {
    const modal = document.getElementById('checkout-modal');
    const content = document.getElementById('checkout-content');
    
    content.classList.remove('scale-100');
    content.classList.add('scale-95');
    
    setTimeout(() => {
        modal.classList.add('opacity-0', 'invisible');
        document.body.classList.remove('overflow-hidden');
    }, 200);
}

// Update checkout summary
function updateCheckoutSummary() {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const modalSubtotal = document.getElementById('modal-subtotal');
    const modalTotal = document.getElementById('modal-total');
    
    if (modalSubtotal) modalSubtotal.textContent = '$' + subtotal.toFixed(2);
    if (modalTotal) modalTotal.textContent = '$' + subtotal.toFixed(2);
}

// Show loading overlay
function showLoadingOverlay() {
    const overlay = document.getElementById('loading-overlay');
    if (overlay) {
        overlay.classList.remove('opacity-0', 'invisible');
    }
}

// Hide loading overlay
function hideLoadingOverlay() {
    const overlay = document.getElementById('loading-overlay');
    if (overlay) {
        overlay.classList.add('opacity-0', 'invisible');
    }
}

async function handleCheckout(e) {
    e.preventDefault();
    
    // Show loading overlay
    showLoadingOverlay();
    
    const formData = new FormData(checkoutForm);
    const orderData = {
        name: formData.get('name'),
        phone: formData.get('phone'),
        address: formData.get('address'),
        notes: formData.get('notes'),
        cart: cart
    };
    
    try {
        const response = await fetch('/checkout', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(orderData)
        });
        
        hideLoadingOverlay();
        
        if (response.ok) {
            const result = await response.json();
            
            // Show success message
            showSuccessNotification('Order placed successfully! You will receive a confirmation shortly.');
            
            // Clear cart
            cart = [];
            await updateCart();
            
            // Close modal and redirect or show success page
            closeCheckoutModal();
            
            if (result.redirect) {
                setTimeout(() => {
                    window.location.href = result.redirect;
                }, 1500);
            } else {
                setTimeout(() => {
                    window.location.href = '/success';
                }, 1500);
            }
        } else {
            const error = await response.text();
            showNotification(`Error: ${error}`, 'error');
        }
    } catch (error) {
        hideLoadingOverlay();
        console.error('Error:', error);
        showNotification('An error occurred while processing your order. Please try again.', 'error');
    }
}

// Product Filtering
function filterProducts(e) {
    e.preventDefault();
    const category = this.dataset.category;
    const productCards = document.querySelectorAll('.product-card');
    
    // Update active filter button
    document.querySelectorAll('.category-filter').forEach(btn => {
        btn.classList.toggle('bg-green-600', btn === this);
        btn.classList.toggle('text-white', btn === this);
        btn.classList.toggle('bg-gray-100', btn !== this);
        btn.classList.toggle('text-gray-800', btn !== this);
    });
    
    // Filter products
    productCards.forEach(card => {
        if (category === 'all' || card.dataset.category === category) {
            card.classList.remove('hidden');
        } else {
            card.classList.add('hidden');
        }
    });
}

// Utility Functions
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    const bgColor = type === 'success' ? 'bg-green-500' : 'bg-red-500';
    const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle';
    
    notification.className = `fixed top-4 right-4 ${bgColor} text-white px-6 py-4 rounded-xl shadow-lg z-50 transform translate-x-full transition-transform duration-300 max-w-sm`;
    notification.innerHTML = `
        <div class="flex items-center">
            <i class="fas ${icon} mr-3 text-lg"></i>
            <span class="font-medium">${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.classList.remove('translate-x-full');
    }, 100);
    
    // Animate out after 4 seconds
    setTimeout(() => {
        notification.classList.add('translate-x-full');
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }, 4000);
}

function showSuccessNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 right-4 bg-gradient-to-r from-green-500 to-green-600 text-white px-6 py-4 rounded-xl shadow-lg z-50 transform translate-x-full transition-all duration-300 max-w-sm';
    notification.innerHTML = `
        <div class="flex items-center">
            <i class="fas fa-check-circle mr-3 text-xl animate-bounce"></i>
            <div>
                <div class="font-bold">Success!</div>
                <div class="text-sm opacity-90">${message}</div>
            </div>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.classList.remove('translate-x-full');
    }, 100);
    
    // Animate out after 5 seconds
    setTimeout(() => {
        notification.classList.add('translate-x-full');
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }, 5000);
}

function showTooltip(e) {
    const tooltip = document.createElement('div');
    tooltip.className = 'absolute z-10 bg-gray-900 text-white text-xs rounded py-1 px-2 whitespace-nowrap';
    tooltip.textContent = this.getAttribute('data-tooltip');
    
    const rect = this.getBoundingClientRect();
    tooltip.style.top = `${rect.bottom + window.scrollY}px`;
    tooltip.style.left = `${rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2)}px`;
    
    document.body.appendChild(tooltip);
    this._tooltip = tooltip;
}

function hideTooltip() {
    if (this._tooltip) {
        this._tooltip.remove();
        this._tooltip = null;
    }
}

// Initialize cart quantity inputs and removal
document.addEventListener('click', (e) => {
    // Handle remove item button clicks (including clicks on SVG/path elements)
    const removeBtn = e.target.closest('.remove-item');
    if (removeBtn) {
        e.preventDefault();
        const productId = parseInt(removeBtn.dataset.id);
        if (confirm('Are you sure you want to remove this item from your cart?')) {
            removeFromCart(productId);
            showNotification('Item removed from cart', 'success');
        }
        return;
    }
    
    // Handle quantity buttons
    if (e.target.classList.contains('quantity-btn')) {
        e.preventDefault();
        const input = e.target.parentElement.querySelector('input[type=number]');
        let value = parseInt(input.value);
        
        if (e.target.classList.contains('minus') && value > 1) {
            input.value = value - 1;
        } else if (e.target.classList.contains('plus')) {
            input.value = value + 1;
        }
        
        // Update cart item quantity
        const itemId = parseInt(e.target.closest('.cart-item').dataset.id);
        const newQuantity = parseInt(input.value);
        updateCartItemQuantity(itemId, newQuantity);
    }
});

// Products data will be loaded from the server
let products = [];

// Load products from server
async function loadProducts() {
    try {
        const response = await fetch('/api/products');
        if (response.ok) {
            const data = await response.json();
            products = data.products || [];
        }
    } catch (error) {
        console.error('Error loading products:', error);
        products = [];
    }
}

// Call loadProducts on page load
loadProducts();
