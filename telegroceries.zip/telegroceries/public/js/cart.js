// DOM Elements
const cartIcon = document.getElementById('cart-icon');
const cartSidebar = document.getElementById('cart-sidebar');
const cartOverlay = document.getElementById('cart-overlay');
const closeCart = document.getElementById('close-cart');
const cartItems = document.getElementById('cart-items');
const cartCount = document.getElementById('cart-count');
const cartTotal = document.getElementById('cart-total');
const checkoutBtn = document.getElementById('checkout-btn');
const checkoutModal = document.getElementById('checkout-modal');
const closeCheckout = document.getElementById('close-checkout');
const checkoutForm = document.getElementById('checkout-form');

// Initialize cart
let cart = [];

// Load cart from server on page load
async function loadCartFromServer() {
    try {
        const response = await fetch('/api/cart');
        if (response.ok) {
            const data = await response.json();
            cart = data.cart || [];
            updateCartUI();
        }
    } catch (error) {
        console.error('Error loading cart:', error);
    }
}

// Update cart on the server
async function updateCartOnServer() {
    try {
        const response = await fetch('/api/cart/update', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ cart })
        });
        
        if (!response.ok) {
            throw new Error('Failed to update cart');
        }
        
        updateCartUI();
    } catch (error) {
        console.error('Error updating cart:', error);
    }
}

// Update cart UI
function updateCartUI() {
    if (!cartItems) return;

    if (cart.length === 0) {
        cartItems.innerHTML = '<p class="text-gray-500 text-center py-8">Your cart is empty</p>';
        cartCount.textContent = '0';
        cartTotal.textContent = '$0.00';
        if (checkoutBtn) checkoutBtn.disabled = true;
        return;
    }

    // Render cart items
    cartItems.innerHTML = cart.map(item => `
        <div class="cart-item flex items-center py-4 border-b border-gray-200" data-id="${item.id}">
            <img src="${item.image}" alt="${item.name}" class="w-16 h-16 object-cover rounded">
            <div class="ml-4 flex-1">
                <h3 class="font-medium text-gray-900">${item.name}</h3>
                <p class="text-gray-600">$${item.price.toFixed(2)} x ${item.quantity}</p>
            </div>
            <div class="flex items-center">
                <button class="quantity-btn minus px-2 py-1 bg-gray-100 rounded-l" data-id="${item.id}">-</button>
                <input type="number" min="1" value="${item.quantity}" class="w-12 text-center border-t border-b border-gray-300">
                <button class="quantity-btn plus px-2 py-1 bg-gray-100 rounded-r" data-id="${item.id}">+</button>
                <button class="remove-item ml-2 text-red-500" data-id="${item.id}">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                </button>
            </div>
        </div>
    `).join('');

    // Update cart count and total
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    const totalPrice = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    cartCount.textContent = totalItems;
    cartTotal.textContent = `$${totalPrice.toFixed(2)}`;
    if (checkoutBtn) checkoutBtn.disabled = false;
}

// Add item to cart
async function addToCart(product, quantity = 1) {
    const existingItem = cart.find(item => item.id === product.id);
    
    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            image: product.image,
            quantity: quantity
        });
    }
    
    await updateCartOnServer();
    showNotification(`${product.name} added to cart`, 'success');
}

// Update item quantity
async function updateCartItemQuantity(productId, newQuantity) {
    const item = cart.find(item => item.id === productId);
    if (item) {
        item.quantity = Math.max(1, newQuantity);
        await updateCartOnServer();
    }
}

// Remove item from cart
async function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    await updateCartOnServer();
}

// Toggle cart sidebar
function toggleCart() {
    if (cartSidebar && cartOverlay) {
        cartSidebar.classList.toggle('translate-x-full');
        cartOverlay.classList.toggle('hidden');
        document.body.classList.toggle('overflow-hidden');
    }
}

// Close cart sidebar
function closeCartSidebar() {
    if (cartSidebar && cartOverlay) {
        cartSidebar.classList.add('translate-x-full');
        cartOverlay.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
    }
}

// Open checkout modal
function openCheckoutModal() {
    if (cart.length === 0) return;
    if (checkoutModal) {
        checkoutModal.classList.remove('hidden');
        document.body.classList.add('overflow-hidden');
    }
}

// Close checkout modal
function closeCheckoutModal() {
    if (checkoutModal) {
        checkoutModal.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
    }
}

// Handle checkout form submission
async function handleCheckout(e) {
    e.preventDefault();
    
    if (!checkoutForm) return;
    
    const submitBtn = checkoutForm.querySelector('button[type="submit"]');
    const originalBtnText = submitBtn.innerHTML;
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<div class="spinner"></div> Processing...';
    
    const formData = new FormData(checkoutForm);
    const orderData = {
        name: formData.get('name'),
        phone: formData.get('phone'),
        address: formData.get('address'),
        notes: formData.get('notes'),
        cart: cart
    };
    
    try {
        const response = await fetch('/checkout', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(orderData)
        });
        
        if (response.ok) {
            const result = await response.json();
            if (result.redirect) {
                window.location.href = result.redirect;
            } else {
                window.location.href = '/success';
            }
        } else {
            const error = await response.text();
            showNotification(`Error: ${error}`, 'error');
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalBtnText;
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('An error occurred while processing your order. Please try again.', 'error');
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalBtnText;
    }
}

// Show notification
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
        type === 'success' ? 'bg-green-500' : 'bg-red-500'
    } text-white`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('opacity-0', 'transition-opacity', 'duration-500');
        setTimeout(() => notification.remove(), 500);
    }, 3000);
}

// Initialize event listeners
document.addEventListener('DOMContentLoaded', () => {
    // Load cart from server
    loadCartFromServer();
    
    // Cart toggle
    if (cartIcon) cartIcon.addEventListener('click', toggleCart);
    if (closeCart) closeCart.addEventListener('click', closeCartSidebar);
    if (cartOverlay) cartOverlay.addEventListener('click', closeCartSidebar);
    
    // Checkout modal
    if (checkoutBtn) checkoutBtn.addEventListener('click', openCheckoutModal);
    if (closeCheckout) closeCheckout.addEventListener('click', closeCheckoutModal);
    
    // Form submission
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', handleCheckout);
    }
    
    // Add to cart buttons
    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('add-to-cart')) {
            e.preventDefault();
            const productId = parseInt(e.target.dataset.id);
            const product = products.find(p => p.id === productId);
            
            if (product) {
                addToCart(product);
            }
        }
    });
    
    // Cart quantity controls
    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('quantity-btn')) {
            e.preventDefault();
            const input = e.target.parentElement.querySelector('input[type=number]');
            if (!input) return;
            
            let value = parseInt(input.value);
            
            if (e.target.classList.contains('minus') && value > 1) {
                input.value = value - 1;
            } else if (e.target.classList.contains('plus')) {
                input.value = value + 1;
            }
            
            // Update cart item quantity
            const itemId = parseInt(e.target.closest('.cart-item')?.dataset.id);
            if (itemId) {
                const newQuantity = parseInt(input.value);
                updateCartItemQuantity(itemId, newQuantity);
            }
        }
    });
    
    // Remove item from cart
    document.addEventListener('click', (e) => {
        if (e.target.closest('.remove-item')) {
            e.preventDefault();
            const productId = parseInt(e.target.closest('.remove-item').dataset.id);
            if (productId) {
                removeFromCart(productId);
            }
        }
    });
});

// Sample products (should be loaded from the server in a real app)
const products = [
    { id: 1, name: 'Fresh Apples', price: 2.99, image: '/images/apples.jpg', category: 'fruits' },
    { id: 2, name: 'Organic Bananas', price: 1.49, image: '/images/bananas.jpg', category: 'fruits' },
    { id: 3, name: 'Carrots', price: 0.99, image: '/images/carrots.jpg', category: 'vegetables' },
    { id: 4, name: 'Milk', price: 2.49, image: '/images/milk.jpg', category: 'dairy' },
];
