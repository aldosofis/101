// Quick fix for admin login - run this to temporarily allow plain text passwords
const fs = require('fs');
const path = require('path');

const appPath = path.join(__dirname, 'app.js');
let appContent = fs.readFileSync(appPath, 'utf8');

// Replace the bcrypt comparison with a temporary plain text comparison
const oldLoginLogic = `    if (username === adminCredentials.username) {
        const isValid = await bcrypt.compare(password, adminCredentials.password);
        if (isValid) {`;

const newLoginLogic = `    if (username === adminCredentials.username) {
        // Temporary plain text comparison for debugging
        const isValid = password === 'password' || await bcrypt.compare(password, adminCredentials.password);
        if (isValid) {`;

if (appContent.includes(oldLoginLogic)) {
    appContent = appContent.replace(oldLoginLogic, newLoginLogic);
    fs.writeFileSync(appPath, appContent);
    console.log('✅ Fixed! You can now login with:');
    console.log('   Username: admin');
    console.log('   Password: password');
    console.log('');
    console.log('🔄 Please restart the server with: npm start');
} else {
    console.log('❌ Could not find the login logic to replace. Please restart the server manually.');
}