# Windows Firewall Configuration for Telegroceries Public IP Access
Write-Host "🔧 Configuring Windows Firewall for Telegroceries..." -ForegroundColor Green

# Check if running as administrator
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    Write-Host "❌ This script must be run as Administrator!" -ForegroundColor Red
    Write-Host "Please right-click PowerShell and 'Run as Administrator'" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

$PORT = 3000

try {
    # Remove existing rules if they exist
    Write-Host "Removing existing firewall rules..." -ForegroundColor Yellow
    netsh advfirewall firewall delete rule name="Telegroceries HTTP Inbound" 2>$null
    netsh advfirewall firewall delete rule name="Telegroceries HTTP Outbound" 2>$null

    # Add inbound rule
    Write-Host "Adding inbound rule for port $PORT..." -ForegroundColor Cyan
    netsh advfirewall firewall add rule name="Telegroceries HTTP Inbound" dir=in action=allow protocol=TCP localport=$PORT

    # Add outbound rule
    Write-Host "Adding outbound rule for port $PORT..." -ForegroundColor Cyan
    netsh advfirewall firewall add rule name="Telegroceries HTTP Outbound" dir=out action=allow protocol=TCP localport=$PORT

    Write-Host "✅ Firewall rules added successfully!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Firewall Rules Created:" -ForegroundColor White
    Write-Host "- Inbound: Allow TCP port $PORT" -ForegroundColor Green
    Write-Host "- Outbound: Allow TCP port $PORT" -ForegroundColor Green
    Write-Host ""
    
    # Get local IP addresses
    Write-Host "📡 Your IP addresses:" -ForegroundColor Cyan
    $ipAddresses = Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -ne "127.0.0.1" -and $_.IPAddress -notlike "169.254.*" } | Select-Object IPAddress, InterfaceAlias
    
    foreach ($ip in $ipAddresses) {
        if ($ip.IPAddress -like "192.168.*" -or $ip.IPAddress -like "10.*" -or $ip.IPAddress -like "172.*") {
            Write-Host "   Local:  http://$($ip.IPAddress):$PORT ($($ip.InterfaceAlias))" -ForegroundColor White
        } else {
            Write-Host "   Public: http://$($ip.IPAddress):$PORT ($($ip.InterfaceAlias))" -ForegroundColor Yellow
        }
    }
    
    Write-Host ""
    Write-Host "🌐 Additional Steps for Public IP Access:" -ForegroundColor Cyan
    Write-Host "1. Configure your router to forward port $PORT to this computer" -ForegroundColor White
    Write-Host "2. Find your public IP at: https://whatismyipaddress.com" -ForegroundColor White
    Write-Host "3. Access via: http://YOUR-PUBLIC-IP:$PORT" -ForegroundColor White
    Write-Host ""
    Write-Host "🔐 Security Note:" -ForegroundColor Yellow
    Write-Host "- Change default admin password: admin/password" -ForegroundColor Red
    Write-Host "- Consider using HTTPS in production" -ForegroundColor Yellow
    Write-Host "- Monitor access logs regularly" -ForegroundColor Yellow
    
} catch {
    Write-Host "❌ Error configuring firewall: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Please try running this script as Administrator" -ForegroundColor Yellow
}

Write-Host ""
Read-Host "Press Enter to continue"