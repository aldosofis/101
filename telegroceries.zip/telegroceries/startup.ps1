# Telegroceries Complete Setup and Startup Script
Write-Host "🚀 Starting Telegroceries Application Setup..." -ForegroundColor Green

# Function to check if a port is in use
function Test-Port($port) {
    $connection = Test-NetConnection -ComputerName localhost -Port $port -WarningAction SilentlyContinue
    return $connection.TcpTestSucceeded
}

# Function to kill processes on port 3000
function Stop-ProcessOnPort($port) {
    $processes = Get-Process -Name "node" -ErrorAction SilentlyContinue
    foreach ($process in $processes) {
        try {
            $connections = netstat -ano | Select-String ":$port "
            foreach ($connection in $connections) {
                $pid = ($connection.ToString() -split '\s+')[-1]
                if ($pid -eq $process.Id) {
                    Write-Host "Stopping process on port $port (PID: $pid)" -ForegroundColor Yellow
                    Stop-Process -Id $pid -Force -ErrorAction SilentlyContinue
                    Start-Sleep -Seconds 2
                    break
                }
            }
        }
        catch {
            # Ignore errors
        }
    }
}

# Check if port 3000 is in use and stop if necessary
if (Test-Port 3000) {
    Write-Host "⚠️ Port 3000 is in use. Stopping existing processes..." -ForegroundColor Yellow
    Stop-ProcessOnPort 3000
    Start-Sleep -Seconds 3
}

# Check Node.js installation
Write-Host "1. Checking Node.js installation..." -ForegroundColor Cyan
try {
    $nodeVersion = node --version
    Write-Host "   ✅ Node.js version: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "   ❌ Node.js not found. Please install Node.js first." -ForegroundColor Red
    exit 1
}

# Check npm installation
Write-Host "2. Checking npm installation..." -ForegroundColor Cyan
try {
    $npmVersion = npm --version
    Write-Host "   ✅ npm version: $npmVersion" -ForegroundColor Green
} catch {
    Write-Host "   ❌ npm not found. Please install npm first." -ForegroundColor Red
    exit 1
}

# Install dependencies
Write-Host "3. Installing/updating dependencies..." -ForegroundColor Cyan
try {
    npm install --silent
    Write-Host "   ✅ Dependencies installed successfully" -ForegroundColor Green
} catch {
    Write-Host "   ❌ Error installing dependencies" -ForegroundColor Red
    exit 1
}

# Check .env file
Write-Host "4. Checking environment configuration..." -ForegroundColor Cyan
if (Test-Path ".env") {
    Write-Host "   ✅ .env file found" -ForegroundColor Green
    
    # Check if admin credentials exist
    $envContent = Get-Content ".env" -Raw
    if ($envContent -match "ADMIN_USERNAME=admin" -and $envContent -match "ADMIN_PASSWORD=") {
        Write-Host "   ✅ Admin credentials configured" -ForegroundColor Green
    } else {
        Write-Host "   ⚠️ Admin credentials may not be properly configured" -ForegroundColor Yellow
    }
    
    # Check Telegram configuration
    if ($envContent -match "TELEGRAM_BOT_TOKEN=" -and $envContent -match "TELEGRAM_CHAT_ID=") {
        Write-Host "   ✅ Telegram bot configuration found" -ForegroundColor Green
    } else {
        Write-Host "   ⚠️ Telegram bot not configured (optional)" -ForegroundColor Yellow
    }
} else {
    Write-Host "   ❌ .env file not found" -ForegroundColor Red
    exit 1
}

# Create required directories if they don't exist
Write-Host "5. Checking directory structure..." -ForegroundColor Cyan
$directories = @("public", "public/css", "public/js", "public/images", "views", "views/admin", "views/layouts")
foreach ($dir in $directories) {
    if (!(Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
        Write-Host "   📁 Created directory: $dir" -ForegroundColor Blue
    }
}
Write-Host "   ✅ Directory structure verified" -ForegroundColor Green

# Verify key files exist
Write-Host "6. Verifying application files..." -ForegroundColor Cyan
$requiredFiles = @(
    "app.js",
    "package.json",
    "views/layouts/main.ejs",
    "views/layouts/admin.ejs",
    "views/admin/login.ejs",
    "views/admin/dashboard.ejs",
    "views/admin/products.ejs",
    "views/admin/product-form.ejs",
    "public/css/style.css",
    "public/js/main.js"
)

$missingFiles = @()
foreach ($file in $requiredFiles) {
    if (!(Test-Path $file)) {
        $missingFiles += $file
    }
}

if ($missingFiles.Count -eq 0) {
    Write-Host "   ✅ All required files present" -ForegroundColor Green
} else {
    Write-Host "   ❌ Missing files:" -ForegroundColor Red
    foreach ($file in $missingFiles) {
        Write-Host "      - $file" -ForegroundColor Red
    }
    exit 1
}

# Test bcrypt password verification
Write-Host "7. Testing admin authentication..." -ForegroundColor Cyan
try {
    $testResult = node -e "
        require('dotenv').config();
        const bcrypt = require('bcryptjs');
        const adminPassword = process.env.ADMIN_PASSWORD;
        if (adminPassword) {
            const isValid = bcrypt.compareSync('password', adminPassword);
            console.log(isValid);
        } else {
            console.log(false);
        }
    "
    
    if ($testResult -eq "true") {
        Write-Host "   ✅ Admin authentication test passed" -ForegroundColor Green
    } else {
        Write-Host "   ❌ Admin authentication test failed" -ForegroundColor Red
        Write-Host "   Regenerating admin password hash..." -ForegroundColor Yellow
        
        # Generate new hash
        $newHash = node -e "
            const bcrypt = require('bcryptjs');
            console.log(bcrypt.hashSync('password', 12));
        "
        
        # Update .env file
        $envContent = Get-Content ".env" -Raw
        $envContent = $envContent -replace "ADMIN_PASSWORD=.*", "ADMIN_PASSWORD=$newHash"
        Set-Content -Path ".env" -Value $envContent
        
        Write-Host "   ✅ Admin password hash regenerated" -ForegroundColor Green
    }
} catch {
    Write-Host "   ❌ Error testing admin authentication" -ForegroundColor Red
    exit 1
}

# Start the server
Write-Host "`n🚀 Starting Telegroceries server..." -ForegroundColor Green
Write-Host "   Server will start on http://localhost:3000" -ForegroundColor Cyan
Write-Host "   Admin panel: http://localhost:3000/admin/login" -ForegroundColor Cyan
Write-Host "   Credentials: admin / password" -ForegroundColor Cyan
Write-Host "`n   Press Ctrl+C to stop the server" -ForegroundColor Yellow
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Gray

# Start the application
Start-Process -FilePath "http://localhost:3000" -ErrorAction SilentlyContinue

try {
    & npm start
} catch {
    Write-Host "`n❌ Server failed to start" -ForegroundColor Red
    exit 1
}