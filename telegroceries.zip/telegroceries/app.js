// Import required modules
require('dotenv').config();
const express = require('express');
const session = require('express-session');
const path = require('path');
const TelegramBot = require('node-telegram-bot-api');
const expressLayouts = require('express-ejs-layouts');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const flash = require('connect-flash');
const { body, validationResult } = require('express-validator');
const helmet = require('helmet');
const cors = require('cors');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Security middleware - configured for public IP access
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://cdn.jsdelivr.net", "https://cdnjs.cloudflare.com"],
            scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
            imgSrc: ["'self'", "data:", "https:", "http:", "*"],
            fontSrc: ["'self'", "https://cdnjs.cloudflare.com", "data:"],
            connectSrc: ["'self'", "*"],
            frameSrc: ["'none'"],
            objectSrc: ["'none'"],
            mediaSrc: ["'self'"],
            manifestSrc: ["'self'"]
        },
        reportOnly: process.env.NODE_ENV !== 'production'
    },
    crossOriginEmbedderPolicy: false,
    crossOriginResourcePolicy: {
        policy: process.env.NODE_ENV === 'production' ? 'same-site' : 'cross-origin'
    }
}));

// Configure CORS for public IP access
const corsOptions = {
    origin: function (origin, callback) {
        // Allow requests with no origin (like mobile apps or curl requests)
        if (!origin) return callback(null, true);
        
        // Allow localhost and any IP address for development
        if (process.env.NODE_ENV !== 'production') {
            return callback(null, true);
        }
        
        // In production, you can specify allowed origins
        const allowedOrigins = [
            process.env.FRONTEND_URL,
            /^https?:\/\/localhost(:\d+)?$/,
            /^https?:\/\/127\.0\.0\.1(:\d+)?$/,
            /^https?:\/\/192\.168\.[0-9]{1,3}\.[0-9]{1,3}(:\d+)?$/,
            /^https?:\/\/10\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}(:\d+)?$/,
        ];
        
        if (process.env.ALLOWED_ORIGINS) {
            allowedOrigins.push(...process.env.ALLOWED_ORIGINS.split(','));
        }
        
        const isAllowed = allowedOrigins.some(allowed => {
            if (typeof allowed === 'string') {
                return origin === allowed;
            } else if (allowed instanceof RegExp) {
                return allowed.test(origin);
            }
            return false;
        });
        
        callback(null, isAllowed);
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
    optionsSuccessStatus: 200
};

app.use(cors(corsOptions));

// Rate limiting for login attempts
const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // limit each IP to 5 requests per windowMs
    message: {
        error: 'Too many login attempts, please try again later.',
        retryAfter: '15 minutes'
    },
    standardHeaders: true,
    legacyHeaders: false,
    skipSuccessfulRequests: true
});

// General rate limiting
const generalLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // limit each IP to 100 requests per windowMs
    standardHeaders: true,
    legacyHeaders: false,
});

app.use(generalLimiter);

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// Session configuration
app.use(session({
    secret: process.env.SESSION_SECRET || 'your-very-secure-secret-key-change-in-production',
    resave: false,
    saveUninitialized: false,
    cookie: { 
        secure: process.env.NODE_ENV === 'production',
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000 // 24 hours
    },
    name: 'sessionId' // Change default session name for security
}));

// Flash messages
app.use(flash());

// View engine setup
app.use(expressLayouts);
app.set('layout', 'layouts/main');
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Products data with proper validation for electronics store
let products = [
    { 
        id: 1, 
        name: 'iPhone 15 Pro', 
        price: 999.99, 
        image: '/images/iphone15pro.jpg', 
        category: 'smartphones', 
        description: 'The most advanced iPhone yet with titanium design and A17 Pro chip.',
        inStock: true,
        createdAt: new Date(),
        updatedAt: new Date(),
        specifications: {
            display: '6.1-inch Super Retina XDR',
            processor: 'A17 Pro chip',
            storage: '128GB, 256GB, 512GB, 1TB',
            camera: '48MP Main, 12MP Ultra Wide, 12MP Telephoto',
            battery: 'Up to 23 hours video playback',
            os: 'iOS 17'
        },
        packages: [
            {
                id: 'basic',
                name: 'Phone Only',
                price: 999.99,
                items: ['iPhone 15 Pro', 'USB-C Cable', 'Documentation']
            },
            {
                id: 'standard',
                name: 'Essentials Package',
                price: 1149.99,
                originalPrice: 1199.99,
                items: ['iPhone 15 Pro', 'USB-C Cable', 'MagSafe Charger', 'Clear Case', 'Screen Protector']
            },
            {
                id: 'premium',
                name: 'Complete Bundle',
                price: 1299.99,
                originalPrice: 1399.99,
                items: ['iPhone 15 Pro', 'USB-C Cable', 'MagSafe Charger', 'Leather Case', 'Screen Protector', 'AirPods (3rd gen)', 'Wireless Stand']
            }
        ],
        notes: 'Free shipping and 1-year warranty included. Compatible with all MagSafe accessories.',
        warranty: '1 Year Limited Warranty',
        rating: 4.8,
        reviewCount: 2847
    },
    { 
        id: 2, 
        name: 'MacBook Air M2', 
        price: 1199.99, 
        image: '/images/macbook-air-m2.jpg', 
        category: 'laptops', 
        description: 'Supercharged by M2 chip. Incredibly thin and light design with all-day battery life.',
        inStock: true,
        createdAt: new Date(),
        updatedAt: new Date(),
        specifications: {
            processor: 'Apple M2 8-core CPU',
            memory: '8GB or 16GB unified memory',
            storage: '256GB, 512GB, 1TB, 2TB SSD',
            display: '13.6-inch Liquid Retina',
            battery: 'Up to 18 hours',
            weight: '2.7 pounds (1.24 kg)'
        },
        packages: [
            {
                id: 'basic',
                name: 'Laptop Only',
                price: 1199.99,
                items: ['MacBook Air M2', 'MagSafe 3 Charging Cable', 'Documentation']
            },
            {
                id: 'standard',
                name: 'Student Package',
                price: 1349.99,
                originalPrice: 1399.99,
                items: ['MacBook Air M2', 'MagSafe 3 Charging Cable', 'USB-C Hub', 'Laptop Sleeve', 'Wireless Mouse']
            },
            {
                id: 'premium',
                name: 'Professional Bundle',
                price: 1599.99,
                originalPrice: 1699.99,
                items: ['MacBook Air M2', 'MagSafe 3 Charging Cable', 'USB-C Hub', 'Premium Laptop Bag', 'Magic Mouse', 'External Monitor Adapter', 'Laptop Stand']
            }
        ],
        notes: 'Perfect for students and professionals. Eco-friendly packaging made from recycled materials.',
        warranty: '1 Year Limited Warranty + 90 Days Technical Support',
        rating: 4.9,
        reviewCount: 3921
    },
    { 
        id: 3, 
        name: 'AirPods Pro (2nd gen)', 
        price: 249.99, 
        image: '/images/airpods-pro.jpg', 
        category: 'audio', 
        description: 'Active Noise Cancellation, Transparency mode, and Personalized Spatial Audio.',
        inStock: true,
        createdAt: new Date(),
        updatedAt: new Date(),
        specifications: {
            chip: 'Apple H2 chip',
            connectivity: 'Bluetooth 5.3',
            battery: 'Up to 6 hours listening time',
            case_battery: 'Up to 30 hours total',
            features: 'Active Noise Cancellation, Transparency mode',
            water_resistance: 'IPX4 sweat and water resistant'
        },
        packages: [
            {
                id: 'basic',
                name: 'AirPods Only',
                price: 249.99,
                items: ['AirPods Pro (2nd gen)', 'MagSafe Charging Case', 'Lightning to USB-C Cable']
            },
            {
                id: 'standard',
                name: 'Enhanced Package',
                price: 299.99,
                originalPrice: 329.99,
                items: ['AirPods Pro (2nd gen)', 'MagSafe Charging Case', 'Lightning to USB-C Cable', 'Extra Ear Tips', 'Cleaning Kit', 'Premium Case']
            }
        ],
        notes: 'Includes multiple ear tip sizes for perfect fit. Compatible with Find My app.',
        warranty: '1 Year Limited Warranty',
        rating: 4.7,
        reviewCount: 5683
    },
    { 
        id: 4, 
        name: 'Gaming Mouse Pro X', 
        price: 89.99, 
        image: '/images/gaming-mouse.jpg', 
        category: 'gaming', 
        description: 'Professional gaming mouse with 25,000 DPI sensor and customizable RGB lighting.',
        inStock: true,
        createdAt: new Date(),
        updatedAt: new Date(),
        specifications: {
            sensor: '25,000 DPI optical sensor',
            buttons: '8 programmable buttons',
            connectivity: 'Wired USB-C, 2.4GHz wireless',
            battery: 'Up to 70 hours wireless',
            weight: '85g (without cable)',
            lighting: 'RGB with 16.8 million colors'
        },
        packages: [
            {
                id: 'basic',
                name: 'Mouse Only',
                price: 89.99,
                items: ['Gaming Mouse Pro X', 'USB-C Cable', 'User Manual']
            },
            {
                id: 'standard',
                name: 'Gamer Package',
                price: 139.99,
                originalPrice: 159.99,
                items: ['Gaming Mouse Pro X', 'USB-C Cable', 'Gaming Mouse Pad', 'Extra Mouse Feet', 'Carrying Pouch']
            },
            {
                id: 'premium',
                name: 'Pro Gamer Bundle',
                price: 199.99,
                originalPrice: 239.99,
                items: ['Gaming Mouse Pro X', 'USB-C Cable', 'XXL Gaming Mouse Pad', 'Extra Mouse Feet', 'Premium Carrying Case', 'Wrist Rest', 'Custom Key Caps']
            }
        ],
        notes: 'Compatible with all major gaming platforms. Software available for Windows and macOS.',
        warranty: '2 Year Limited Warranty',
        rating: 4.6,
        reviewCount: 1247
    },
    {
        id: 5,
        name: 'Wireless Charging Stand',
        price: 49.99,
        image: '/images/wireless-charger.jpg',
        category: 'accessories',
        description: '15W fast wireless charging stand compatible with iPhone, Samsung, and other Qi-enabled devices.',
        inStock: true,
        createdAt: new Date(),
        updatedAt: new Date(),
        specifications: {
            power: '15W, 10W, 7.5W, 5W',
            compatibility: 'iPhone 8+, Samsung Galaxy S6+, Google Pixel 3+',
            design: 'Adjustable stand with anti-slip base',
            safety: 'Over-temperature, over-voltage, over-current protection',
            led_indicator: 'Smart LED charging status',
            dimensions: '4.3 x 3.9 x 4.7 inches'
        },
        packages: [
            {
                id: 'basic',
                name: 'Charger Only',
                price: 49.99,
                items: ['Wireless Charging Stand', 'USB-C Cable', 'User Manual']
            },
            {
                id: 'standard',
                name: 'Multi-Device Package',
                price: 89.99,
                originalPrice: 99.99,
                items: ['Wireless Charging Stand', 'USB-C Cable', '20W USB-C Wall Adapter', 'Cable Management Kit']
            }
        ],
        notes: 'Works with phone cases up to 5mm thick. LED indicator shows charging status.',
        warranty: '18 Months Limited Warranty',
        rating: 4.5,
        reviewCount: 892
    },
    {
        id: 6,
        name: 'Smart Watch Series 9',
        price: 399.99,
        image: '/images/smartwatch.jpg',
        category: 'wearables',
        description: 'Advanced health monitoring, fitness tracking, and seamless connectivity in a sleek design.',
        inStock: true,
        createdAt: new Date(),
        updatedAt: new Date(),
        specifications: {
            display: '1.9-inch AMOLED always-on display',
            processor: 'Dual-core 64-bit S9 SiP',
            storage: '64GB',
            sensors: 'Heart rate, ECG, Blood oxygen, Temperature',
            battery: 'Up to 18 hours all-day battery',
            connectivity: 'Wi-Fi, Bluetooth 5.3, GPS, Cellular (optional)'
        },
        packages: [
            {
                id: 'basic',
                name: 'Watch Only',
                price: 399.99,
                items: ['Smart Watch Series 9', 'Sport Band', 'Magnetic Charging Cable']
            },
            {
                id: 'standard',
                name: 'Fitness Package',
                price: 479.99,
                originalPrice: 519.99,
                items: ['Smart Watch Series 9', 'Sport Band', 'Leather Band', 'Magnetic Charging Cable', 'Screen Protector', 'Charging Stand']
            },
            {
                id: 'premium',
                name: 'Complete Collection',
                price: 599.99,
                originalPrice: 679.99,
                items: ['Smart Watch Series 9', 'Sport Band', 'Leather Band', 'Milanese Loop', 'Magnetic Charging Cable', 'Screen Protector', 'Wireless Charging Stand', 'Premium Case']
            }
        ],
        notes: 'Health features require compatible iPhone. Some features may require cellular plan.',
        warranty: '1 Year Limited Warranty',
        rating: 4.8,
        reviewCount: 4156
    }
];

// Admin credentials with proper hashing
const adminCredentials = {
    username: process.env.ADMIN_USERNAME || 'admin',
    password: process.env.ADMIN_PASSWORD || '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewIVLB5aJvLu2WzC' // 'password'
};

// Utility functions
function getNextProductId() {
    return Math.max(...products.map(p => p.id), 0) + 1;
}

function findProductById(id) {
    const productId = parseInt(id);
    if (isNaN(productId)) {
        throw new Error('Invalid product ID');
    }
    return products.find(p => p.id === productId);
}

function validateProduct(productData) {
    const errors = [];
    
    if (!productData.name || productData.name.trim().length < 2) {
        errors.push('Product name must be at least 2 characters long');
    }
    
    const price = parseFloat(productData.price);
    if (isNaN(price) || price <= 0) {
        errors.push('Price must be a positive number');
    }
    
    if (!productData.category || productData.category.trim().length < 2) {
        errors.push('Category must be at least 2 characters long');
    }
    
    return errors;
}

// Authentication middleware
function requireAuth(req, res, next) {
    if (req.session.isAdmin) {
        return next();
    }
    req.flash('error', 'Please log in to access the admin panel.');
    res.redirect('/admin/login');
}

function preventAuthAccess(req, res, next) {
    if (req.session.isAdmin) {
        return res.redirect('/admin');
    }
    next();
}

// Global middleware
app.use((req, res, next) => {
    res.locals.cart = req.session.cart || [];
    res.locals.categories = [...new Set(products.map(p => p.category))];
    res.locals.messages = req.flash();
    res.locals.isAdmin = req.session.isAdmin || false;
    res.locals.currentPath = req.path;
    next();
});

// Error handling middleware
app.use((req, res, next) => {
    res.locals.formatPrice = (price) => {
        if (typeof price !== 'number' || isNaN(price)) {
            return '$0.00';
        }
        return '$' + price.toFixed(2);
    };
    
    res.locals.formatDate = (date) => {
        if (!date) return 'N/A';
        return new Date(date).toLocaleDateString();
    };
    
    next();
});

// Initialize Telegram Bot with proper error handling
let bot = null;
const botToken = process.env.TELEGRAM_BOT_TOKEN;
const chatId = process.env.TELEGRAM_CHAT_ID;

if (botToken && chatId) {
    try {
        bot = new TelegramBot(botToken, { polling: false });
        console.log('✅ Telegram bot initialized successfully');
    } catch (error) {
        console.error('❌ Error initializing Telegram bot:', error.message);
        bot = null;
    }
} else {
    console.warn('⚠️ Telegram bot not configured. Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in .env');
}

// Main routes
app.get('/', (req, res) => {
    try {
        const availableProducts = products.filter(p => p.inStock);
        res.render('index', {
            title: 'Telegroceries - Fresh Products Delivered',
            products: availableProducts
        });
    } catch (error) {
        console.error('Error rendering homepage:', error);
        res.status(500).render('error', {
            title: 'Server Error',
            message: 'Something went wrong loading the homepage.'
        });
    }
});

app.get('/product/:id', (req, res) => {
    try {
        const product = findProductById(req.params.id);
        if (!product) {
            return res.status(404).render('404', {
                title: 'Product Not Found',
                message: 'The product you are looking for does not exist.'
            });
        }

        const relatedProducts = products
            .filter(p => p.id !== product.id && p.category === product.category && p.inStock)
            .slice(0, 4);

        res.render('product', {
            product,
            relatedProducts,
            title: product.name
        });
    } catch (error) {
        console.error('Error rendering product page:', error);
        res.status(500).render('error', {
            title: 'Server Error',
            message: 'Error loading product details.'
        });
    }
});

// Products API for frontend
app.get('/api/products', (req, res) => {
    try {
        const availableProducts = products.filter(p => p.inStock);
        res.json({ 
            success: true,
            products: availableProducts 
        });
    } catch (error) {
        console.error('Error getting products:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error retrieving products' 
        });
    }
});

// Cart API routes with validation
app.get('/api/cart', (req, res) => {
    try {
        if (!req.session.cart) req.session.cart = [];
        res.json({ 
            success: true,
            cart: req.session.cart 
        });
    } catch (error) {
        console.error('Error getting cart:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error retrieving cart data' 
        });
    }
});

app.post('/api/cart/update', (req, res) => {
    try {
        if (!req.session.cart) req.session.cart = [];
        
        const { cart: clientCart } = req.body;
        
        if (!Array.isArray(clientCart)) {
            return res.status(400).json({ 
                success: false, 
                message: 'Invalid cart data format' 
            });
        }

        // Validate cart items
        const validCart = clientCart.every(item => 
            item && 
            typeof item.id === 'number' && 
            typeof item.quantity === 'number' && 
            item.quantity > 0 &&
            Number.isInteger(item.quantity) &&
            findProductById(item.id) // Ensure product exists
        );
        
        if (validCart) {
            req.session.cart = clientCart;
            return res.json({ success: true, cart: req.session.cart });
        } else {
            return res.status(400).json({ 
                success: false, 
                message: 'Invalid cart items' 
            });
        }
    } catch (error) {
        console.error('Error updating cart:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error updating cart' 
        });
    }
});

app.post('/api/cart/add', (req, res) => {
    try {
        if (!req.session.cart) req.session.cart = [];

        const { productId, quantity = 1 } = req.body;
        const product = findProductById(productId);

        if (!product) {
            return res.status(404).json({ 
                success: false, 
                message: 'Product not found' 
            });
        }

        if (!product.inStock) {
            return res.status(400).json({ 
                success: false, 
                message: 'Product is out of stock' 
            });
        }

        const quantityNum = parseInt(quantity);
        if (isNaN(quantityNum) || quantityNum <= 0) {
            return res.status(400).json({ 
                success: false, 
                message: 'Invalid quantity' 
            });
        }

        const cartItem = req.session.cart.find(item => item.id === product.id);
        if (cartItem) {
            cartItem.quantity += quantityNum;
        } else {
            req.session.cart.push({
                id: product.id,
                name: product.name,
                price: product.price,
                quantity: quantityNum,
                image: product.image
            });
        }

        res.json({ success: true, cart: req.session.cart });
    } catch (error) {
        console.error('Error adding to cart:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error adding item to cart' 
        });
    }
});

// Remove item from cart
app.post('/api/cart/remove', (req, res) => {
    try {
        if (!req.session.cart) req.session.cart = [];

        const { productId } = req.body;
        if (!productId || isNaN(parseInt(productId))) {
            return res.status(400).json({ 
                success: false, 
                message: 'Invalid product ID' 
            });
        }

        const originalLength = req.session.cart.length;
        req.session.cart = req.session.cart.filter(item => item.id !== parseInt(productId));
        
        if (req.session.cart.length === originalLength) {
            return res.status(404).json({ 
                success: false, 
                message: 'Item not found in cart' 
            });
        }

        res.json({ 
            success: true, 
            cart: req.session.cart,
            message: 'Item removed from cart' 
        });
    } catch (error) {
        console.error('Error removing from cart:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error removing item from cart' 
        });
    }
});

// Checkout route with comprehensive validation
app.post('/checkout', [
    body('name').trim().isLength({ min: 2 }).escape().withMessage('Name must be at least 2 characters long'),
    body('phone').trim().isMobilePhone().withMessage('Please provide a valid phone number'),
    body('address').trim().isLength({ min: 5 }).escape().withMessage('Address must be at least 5 characters long'),
    body('notes').optional().trim().escape()
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ 
                success: false,
                error: 'Validation failed',
                details: errors.array()
            });
        }

        const { name, phone, address, notes, cart } = req.body;
        
        // Validate cart
        if (!cart || !Array.isArray(cart) || cart.length === 0) {
            return res.status(400).json({ 
                success: false,
                error: 'Your cart is empty' 
            });
        }

        // Validate cart items exist and calculate total
        let total = 0;
        let orderDetails = '';
        
        for (const item of cart) {
            const product = findProductById(item.id);
            if (!product) {
                return res.status(400).json({ 
                    success: false,
                    error: `Product ${item.name} no longer exists` 
                });
            }
            
            if (!product.inStock) {
                return res.status(400).json({ 
                    success: false,
                    error: `Product ${item.name} is out of stock` 
                });
            }
            
            const itemTotal = product.price * item.quantity;
            orderDetails += `- ${product.name} x${item.quantity}: $${itemTotal.toFixed(2)}\n`;
            total += itemTotal;
        }

        // Format message for Telegram
        let message = `🛒 *New Order Received*\n\n`;
        message += `👤 *Customer:* ${name}\n`;
        message += `📞 *Phone:* ${phone}\n`;
        message += `📍 *Address:* ${address}\n`;
        if (notes) message += `📝 *Notes:* ${notes}\n\n`;
        message += `*Order Details:*\n${orderDetails}\n`;
        message += `💰 *Total: $${total.toFixed(2)}*`;

        // Send to Telegram if configured
        if (bot) {
            try {
                await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
            } catch (telegramError) {
                console.error('Error sending to Telegram:', telegramError.message);
                // Continue processing even if Telegram fails
            }
        }
        
        // Log order
        console.log('✅ New order received:', { 
            name, 
            phone, 
            address, 
            total: total.toFixed(2), 
            items: cart.length,
            timestamp: new Date().toISOString()
        });
        
        // Clear cart
        req.session.cart = [];
        
        res.json({ 
            success: true,
            redirect: '/success',
            orderId: Date.now(), // Simple order ID
            total: total.toFixed(2)
        });
        
    } catch (error) {
        console.error('Error processing checkout:', error);
        res.status(500).json({ 
            success: false,
            error: 'Error processing your order. Please try again.' 
        });
    }
});

app.get('/success', (req, res) => {
    try {
        res.render('success', {
            title: 'Order Placed Successfully',
            message: 'Thank you for your order! We\'ll contact you soon with delivery details.'
        });
    } catch (error) {
        console.error('Error rendering success page:', error);
        res.redirect('/');
    }
});

// Admin authentication routes
app.get('/admin/login', preventAuthAccess, (req, res) => {
    try {
        res.render('admin/login', {
            title: 'Admin Login',
            layout: 'layouts/admin'
        });
    } catch (error) {
        console.error('Error rendering admin login:', error);
        res.status(500).send('Error loading login page');
    }
});

app.post('/admin/login', [
    loginLimiter,
    preventAuthAccess,
    body('username').trim().isLength({ min: 3 }).escape(),
    body('password').isLength({ min: 3 })
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            req.flash('error', 'Invalid username or password format.');
            return res.redirect('/admin/login');
        }

        const { username, password } = req.body;
        
        if (username === adminCredentials.username) {
            const isValid = await bcrypt.compare(password, adminCredentials.password);
            if (isValid) {
                req.session.isAdmin = true;
                req.session.adminLoginTime = new Date();
                req.flash('success', 'Welcome to the admin panel!');
                return res.redirect('/admin');
            }
        }
        
        req.flash('error', 'Invalid username or password.');
        res.redirect('/admin/login');
        
    } catch (error) {
        console.error('Error during admin login:', error);
        req.flash('error', 'Login error. Please try again.');
        res.redirect('/admin/login');
    }
});

app.get('/admin/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Error destroying session:', err);
            return res.redirect('/admin');
        }
        res.redirect('/admin/login');
    });
});

// Admin dashboard routes
app.get('/admin', requireAuth, (req, res) => {
    try {
        const stats = {
            totalProducts: products.length,
            inStockProducts: products.filter(p => p.inStock).length,
            outOfStockProducts: products.filter(p => !p.inStock).length,
            categories: [...new Set(products.map(p => p.category))].length,
            avgPrice: products.length > 0 
                ? (products.reduce((sum, p) => sum + p.price, 0) / products.length).toFixed(2)
                : '0.00'
        };

        res.render('admin/dashboard', {
            title: 'Admin Dashboard',
            layout: 'layouts/admin',
            products: products.slice(0, 6), // Recent products
            stats
        });
    } catch (error) {
        console.error('Error rendering admin dashboard:', error);
        res.status(500).render('error', {
            title: 'Dashboard Error',
            message: 'Error loading admin dashboard.',
            layout: 'layouts/admin'
        });
    }
});

app.get('/admin/products', requireAuth, (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const search = req.query.search || '';
        const category = req.query.category || '';

        let filteredProducts = products;

        // Apply search filter
        if (search) {
            filteredProducts = filteredProducts.filter(p => 
                p.name.toLowerCase().includes(search.toLowerCase()) ||
                p.description.toLowerCase().includes(search.toLowerCase())
            );
        }

        // Apply category filter
        if (category && category !== 'all') {
            filteredProducts = filteredProducts.filter(p => p.category === category);
        }

        // Pagination
        const total = filteredProducts.length;
        const totalPages = Math.ceil(total / limit);
        const startIndex = (page - 1) * limit;
        const endIndex = startIndex + limit;
        const paginatedProducts = filteredProducts.slice(startIndex, endIndex);

        res.render('admin/products', {
            title: 'Manage Products',
            layout: 'layouts/admin',
            products: paginatedProducts,
            pagination: {
                page,
                totalPages,
                total,
                limit,
                hasNext: page < totalPages,
                hasPrev: page > 1
            },
            filters: { search, category }
        });
    } catch (error) {
        console.error('Error rendering products page:', error);
        res.status(500).render('error', {
            title: 'Products Error',
            message: 'Error loading products page.',
            layout: 'layouts/admin'
        });
    }
});

// Product management routes
app.get('/admin/products/add', requireAuth, (req, res) => {
    try {
        res.render('admin/product-form', {
            title: 'Add Product',
            layout: 'layouts/admin',
            product: null,
            action: 'add'
        });
    } catch (error) {
        console.error('Error rendering add product page:', error);
        res.status(500).render('error', {
            title: 'Add Product Error',
            message: 'Error loading add product page.',
            layout: 'layouts/admin'
        });
    }
});

app.post('/admin/products/add', [
    requireAuth,
    body('name').trim().isLength({ min: 2 }).escape().withMessage('Product name must be at least 2 characters'),
    body('price').isFloat({ min: 0.01 }).withMessage('Price must be a positive number'),
    body('category').trim().isLength({ min: 2 }).escape().withMessage('Category must be at least 2 characters'),
    body('description').optional().trim().escape(),
    body('image').optional().trim().isURL().withMessage('Image must be a valid URL')
], (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            req.flash('error', errors.array().map(e => e.msg).join(', '));
            return res.redirect('/admin/products/add');
        }

        const { name, price, category, description, image } = req.body;
        
        // Check if product with same name exists
        const existingProduct = products.find(p => 
            p.name.toLowerCase() === name.trim().toLowerCase()
        );
        
        if (existingProduct) {
            req.flash('error', 'A product with this name already exists.');
            return res.redirect('/admin/products/add');
        }
        
        const newProduct = {
            id: getNextProductId(),
            name: name.trim(),
            price: parseFloat(price),
            category: category.trim().toLowerCase(),
            description: description ? description.trim() : '',
            image: image ? image.trim() : '/images/default-product.jpg',
            inStock: true,
            createdAt: new Date(),
            updatedAt: new Date()
        };
        
        products.push(newProduct);
        console.log('✅ Product added:', newProduct.name);
        req.flash('success', 'Product added successfully!');
        res.redirect('/admin/products');
        
    } catch (error) {
        console.error('Error adding product:', error);
        req.flash('error', 'Error adding product. Please try again.');
        res.redirect('/admin/products/add');
    }
});

app.get('/admin/products/edit/:id', requireAuth, (req, res) => {
    try {
        const product = findProductById(req.params.id);
        if (!product) {
            req.flash('error', 'Product not found.');
            return res.redirect('/admin/products');
        }
        
        res.render('admin/product-form', {
            title: 'Edit Product',
            layout: 'layouts/admin',
            product: product,
            action: 'edit'
        });
    } catch (error) {
        console.error('Error rendering edit product page:', error);
        req.flash('error', 'Error loading product for editing.');
        res.redirect('/admin/products');
    }
});

app.post('/admin/products/edit/:id', [
    requireAuth,
    body('name').trim().isLength({ min: 2 }).escape().withMessage('Product name must be at least 2 characters'),
    body('price').isFloat({ min: 0.01 }).withMessage('Price must be a positive number'),
    body('category').trim().isLength({ min: 2 }).escape().withMessage('Category must be at least 2 characters'),
    body('description').optional().trim().escape(),
    body('image').optional().trim().isURL().withMessage('Image must be a valid URL'),
    body('inStock').optional().isBoolean()
], (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            req.flash('error', errors.array().map(e => e.msg).join(', '));
            return res.redirect(`/admin/products/edit/${req.params.id}`);
        }

        const productId = parseInt(req.params.id);
        const productIndex = products.findIndex(p => p.id === productId);
        
        if (productIndex === -1) {
            req.flash('error', 'Product not found.');
            return res.redirect('/admin/products');
        }
        
        const { name, price, category, description, image, inStock } = req.body;
        
        // Check if another product with same name exists
        const existingProduct = products.find(p => 
            p.id !== productId && 
            p.name.toLowerCase() === name.trim().toLowerCase()
        );
        
        if (existingProduct) {
            req.flash('error', 'Another product with this name already exists.');
            return res.redirect(`/admin/products/edit/${productId}`);
        }
        
        products[productIndex] = {
            ...products[productIndex],
            name: name.trim(),
            price: parseFloat(price),
            category: category.trim().toLowerCase(),
            description: description ? description.trim() : '',
            image: image ? image.trim() : products[productIndex].image,
            inStock: inStock === 'true' || inStock === true,
            updatedAt: new Date()
        };
        
        console.log('✅ Product updated:', products[productIndex].name);
        req.flash('success', 'Product updated successfully!');
        res.redirect('/admin/products');
        
    } catch (error) {
        console.error('Error updating product:', error);
        req.flash('error', 'Error updating product. Please try again.');
        res.redirect(`/admin/products/edit/${req.params.id}`);
    }
});

app.delete('/admin/products/:id', requireAuth, (req, res) => {
    try {
        const productId = parseInt(req.params.id);
        const productIndex = products.findIndex(p => p.id === productId);
        
        if (productIndex === -1) {
            return res.status(404).json({ 
                success: false, 
                message: 'Product not found.' 
            });
        }
        
        const deletedProduct = products[productIndex];
        products.splice(productIndex, 1);
        
        console.log('✅ Product deleted:', deletedProduct.name);
        res.json({ 
            success: true, 
            message: 'Product deleted successfully!' 
        });
        
    } catch (error) {
        console.error('Error deleting product:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error deleting product.' 
        });
    }
});

// 404 handler
app.use((req, res) => {
    res.status(404).render('404', {
        title: 'Page Not Found',
        message: 'The page you are looking for does not exist.'
    });
});

// Global error handler
app.use((err, req, res, next) => {
    console.error('💥 Unhandled error:', err);
    
    // Don't expose error details in production
    const message = process.env.NODE_ENV === 'production' 
        ? 'Something went wrong. Please try again later.'
        : err.message;
    
    res.status(err.status || 500).render('error', {
        title: 'Server Error',
        message: message,
        layout: req.path.startsWith('/admin') ? 'layouts/admin' : 'layouts/main'
    });
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('🛑 SIGTERM received, shutting down gracefully');
    server.close(() => {
        console.log('💤 Process terminated');
    });
});

process.on('SIGINT', () => {
    console.log('\n🛑 SIGINT received, shutting down gracefully');
    server.close(() => {
        console.log('💤 Process terminated');
    });
});

// Start server - bind to all interfaces for public IP access
const HOST = process.env.HOST || '0.0.0.0';
const server = app.listen(PORT, HOST, () => {
    console.log(`🚀 Server is running on http://${HOST}:${PORT}`);
    console.log(`🔗 Admin panel: http://localhost:${PORT}/admin/login`);
    console.log(`👤 Admin credentials: admin / password`);
    
    // Show network interfaces
    const os = require('os');
    const networkInterfaces = os.networkInterfaces();
    console.log('\n📡 Available on:');
    Object.keys(networkInterfaces).forEach(interfaceName => {
        networkInterfaces[interfaceName].forEach(iface => {
            if (iface.family === 'IPv4' && !iface.internal) {
                console.log(`   http://${iface.address}:${PORT}`);
            }
        });
    });
    
    if (bot) {
        console.log('\n📱 Telegram notifications enabled');
    } else {
        console.log('\n⚠️  Telegram notifications disabled');
    }
    
    console.log('\n🔧 For public IP access, make sure:');
    console.log('   - Firewall allows port', PORT);
    console.log('   - Router forwards port', PORT, '(if needed)');
    console.log('   - Security groups allow inbound traffic (cloud)');
});

module.exports = app;